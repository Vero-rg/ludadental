import AppointmentController from './AppointmentController'
import TreatmentResultController from './TreatmentResultController'
const Admin = {
    AppointmentController: Object.assign(AppointmentController, AppointmentController),
TreatmentResultController: Object.assign(TreatmentResultController, TreatmentResultController),
}

export default Admin