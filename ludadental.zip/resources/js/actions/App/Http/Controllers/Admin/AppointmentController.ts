import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\AppointmentController::index
 * @see app/Http/Controllers/Admin/AppointmentController.php:22
 * @route '/admin/citas'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/citas',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\AppointmentController::index
 * @see app/Http/Controllers/Admin/AppointmentController.php:22
 * @route '/admin/citas'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AppointmentController::index
 * @see app/Http/Controllers/Admin/AppointmentController.php:22
 * @route '/admin/citas'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\AppointmentController::index
 * @see app/Http/Controllers/Admin/AppointmentController.php:22
 * @route '/admin/citas'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\AppointmentController::index
 * @see app/Http/Controllers/Admin/AppointmentController.php:22
 * @route '/admin/citas'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\AppointmentController::index
 * @see app/Http/Controllers/Admin/AppointmentController.php:22
 * @route '/admin/citas'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\AppointmentController::index
 * @see app/Http/Controllers/Admin/AppointmentController.php:22
 * @route '/admin/citas'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Admin\AppointmentController::updateStatus
 * @see app/Http/Controllers/Admin/AppointmentController.php:74
 * @route '/admin/citas/{appointment}/estado'
 */
export const updateStatus = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateStatus.url(args, options),
    method: 'patch',
})

updateStatus.definition = {
    methods: ["patch"],
    url: '/admin/citas/{appointment}/estado',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Admin\AppointmentController::updateStatus
 * @see app/Http/Controllers/Admin/AppointmentController.php:74
 * @route '/admin/citas/{appointment}/estado'
 */
updateStatus.url = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { appointment: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { appointment: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    appointment: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        appointment: typeof args.appointment === 'object'
                ? args.appointment.id
                : args.appointment,
                }

    return updateStatus.definition.url
            .replace('{appointment}', parsedArgs.appointment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AppointmentController::updateStatus
 * @see app/Http/Controllers/Admin/AppointmentController.php:74
 * @route '/admin/citas/{appointment}/estado'
 */
updateStatus.patch = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateStatus.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Admin\AppointmentController::updateStatus
 * @see app/Http/Controllers/Admin/AppointmentController.php:74
 * @route '/admin/citas/{appointment}/estado'
 */
    const updateStatusForm = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateStatus.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AppointmentController::updateStatus
 * @see app/Http/Controllers/Admin/AppointmentController.php:74
 * @route '/admin/citas/{appointment}/estado'
 */
        updateStatusForm.patch = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateStatus.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateStatus.form = updateStatusForm
/**
* @see \App\Http\Controllers\Admin\AppointmentController::reschedule
 * @see app/Http/Controllers/Admin/AppointmentController.php:91
 * @route '/admin/citas/{appointment}/reagendar'
 */
export const reschedule = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: reschedule.url(args, options),
    method: 'patch',
})

reschedule.definition = {
    methods: ["patch"],
    url: '/admin/citas/{appointment}/reagendar',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Admin\AppointmentController::reschedule
 * @see app/Http/Controllers/Admin/AppointmentController.php:91
 * @route '/admin/citas/{appointment}/reagendar'
 */
reschedule.url = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { appointment: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { appointment: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    appointment: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        appointment: typeof args.appointment === 'object'
                ? args.appointment.id
                : args.appointment,
                }

    return reschedule.definition.url
            .replace('{appointment}', parsedArgs.appointment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AppointmentController::reschedule
 * @see app/Http/Controllers/Admin/AppointmentController.php:91
 * @route '/admin/citas/{appointment}/reagendar'
 */
reschedule.patch = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: reschedule.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Admin\AppointmentController::reschedule
 * @see app/Http/Controllers/Admin/AppointmentController.php:91
 * @route '/admin/citas/{appointment}/reagendar'
 */
    const rescheduleForm = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: reschedule.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AppointmentController::reschedule
 * @see app/Http/Controllers/Admin/AppointmentController.php:91
 * @route '/admin/citas/{appointment}/reagendar'
 */
        rescheduleForm.patch = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: reschedule.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    reschedule.form = rescheduleForm
const AppointmentController = { index, updateStatus, reschedule }

export default AppointmentController