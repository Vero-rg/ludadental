import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\TreatmentResultController::index
 * @see app/Http/Controllers/Admin/TreatmentResultController.php:22
 * @route '/admin/resultados'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/resultados',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\TreatmentResultController::index
 * @see app/Http/Controllers/Admin/TreatmentResultController.php:22
 * @route '/admin/resultados'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\TreatmentResultController::index
 * @see app/Http/Controllers/Admin/TreatmentResultController.php:22
 * @route '/admin/resultados'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\TreatmentResultController::index
 * @see app/Http/Controllers/Admin/TreatmentResultController.php:22
 * @route '/admin/resultados'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\TreatmentResultController::index
 * @see app/Http/Controllers/Admin/TreatmentResultController.php:22
 * @route '/admin/resultados'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\TreatmentResultController::index
 * @see app/Http/Controllers/Admin/TreatmentResultController.php:22
 * @route '/admin/resultados'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\TreatmentResultController::index
 * @see app/Http/Controllers/Admin/TreatmentResultController.php:22
 * @route '/admin/resultados'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Admin\TreatmentResultController::store
 * @see app/Http/Controllers/Admin/TreatmentResultController.php:44
 * @route '/admin/resultados'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/resultados',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\TreatmentResultController::store
 * @see app/Http/Controllers/Admin/TreatmentResultController.php:44
 * @route '/admin/resultados'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\TreatmentResultController::store
 * @see app/Http/Controllers/Admin/TreatmentResultController.php:44
 * @route '/admin/resultados'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\TreatmentResultController::store
 * @see app/Http/Controllers/Admin/TreatmentResultController.php:44
 * @route '/admin/resultados'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\TreatmentResultController::store
 * @see app/Http/Controllers/Admin/TreatmentResultController.php:44
 * @route '/admin/resultados'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Admin\TreatmentResultController::update
 * @see app/Http/Controllers/Admin/TreatmentResultController.php:79
 * @route '/admin/resultados/{result}'
 */
export const update = (args: { result: number | { id: number } } | [result: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: update.url(args, options),
    method: 'post',
})

update.definition = {
    methods: ["post"],
    url: '/admin/resultados/{result}',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\TreatmentResultController::update
 * @see app/Http/Controllers/Admin/TreatmentResultController.php:79
 * @route '/admin/resultados/{result}'
 */
update.url = (args: { result: number | { id: number } } | [result: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { result: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { result: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    result: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        result: typeof args.result === 'object'
                ? args.result.id
                : args.result,
                }

    return update.definition.url
            .replace('{result}', parsedArgs.result.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\TreatmentResultController::update
 * @see app/Http/Controllers/Admin/TreatmentResultController.php:79
 * @route '/admin/resultados/{result}'
 */
update.post = (args: { result: number | { id: number } } | [result: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: update.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\TreatmentResultController::update
 * @see app/Http/Controllers/Admin/TreatmentResultController.php:79
 * @route '/admin/resultados/{result}'
 */
    const updateForm = (args: { result: number | { id: number } } | [result: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\TreatmentResultController::update
 * @see app/Http/Controllers/Admin/TreatmentResultController.php:79
 * @route '/admin/resultados/{result}'
 */
        updateForm.post = (args: { result: number | { id: number } } | [result: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, options),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Admin\TreatmentResultController::toggleVisibility
 * @see app/Http/Controllers/Admin/TreatmentResultController.php:121
 * @route '/admin/resultados/{result}/visibilidad'
 */
export const toggleVisibility = (args: { result: number | { id: number } } | [result: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: toggleVisibility.url(args, options),
    method: 'patch',
})

toggleVisibility.definition = {
    methods: ["patch"],
    url: '/admin/resultados/{result}/visibilidad',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Admin\TreatmentResultController::toggleVisibility
 * @see app/Http/Controllers/Admin/TreatmentResultController.php:121
 * @route '/admin/resultados/{result}/visibilidad'
 */
toggleVisibility.url = (args: { result: number | { id: number } } | [result: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { result: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { result: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    result: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        result: typeof args.result === 'object'
                ? args.result.id
                : args.result,
                }

    return toggleVisibility.definition.url
            .replace('{result}', parsedArgs.result.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\TreatmentResultController::toggleVisibility
 * @see app/Http/Controllers/Admin/TreatmentResultController.php:121
 * @route '/admin/resultados/{result}/visibilidad'
 */
toggleVisibility.patch = (args: { result: number | { id: number } } | [result: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: toggleVisibility.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Admin\TreatmentResultController::toggleVisibility
 * @see app/Http/Controllers/Admin/TreatmentResultController.php:121
 * @route '/admin/resultados/{result}/visibilidad'
 */
    const toggleVisibilityForm = (args: { result: number | { id: number } } | [result: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: toggleVisibility.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\TreatmentResultController::toggleVisibility
 * @see app/Http/Controllers/Admin/TreatmentResultController.php:121
 * @route '/admin/resultados/{result}/visibilidad'
 */
        toggleVisibilityForm.patch = (args: { result: number | { id: number } } | [result: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: toggleVisibility.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    toggleVisibility.form = toggleVisibilityForm
/**
* @see \App\Http\Controllers\Admin\TreatmentResultController::destroy
 * @see app/Http/Controllers/Admin/TreatmentResultController.php:144
 * @route '/admin/resultados/{result}'
 */
export const destroy = (args: { result: number | { id: number } } | [result: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/resultados/{result}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Admin\TreatmentResultController::destroy
 * @see app/Http/Controllers/Admin/TreatmentResultController.php:144
 * @route '/admin/resultados/{result}'
 */
destroy.url = (args: { result: number | { id: number } } | [result: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { result: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { result: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    result: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        result: typeof args.result === 'object'
                ? args.result.id
                : args.result,
                }

    return destroy.definition.url
            .replace('{result}', parsedArgs.result.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\TreatmentResultController::destroy
 * @see app/Http/Controllers/Admin/TreatmentResultController.php:144
 * @route '/admin/resultados/{result}'
 */
destroy.delete = (args: { result: number | { id: number } } | [result: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Admin\TreatmentResultController::destroy
 * @see app/Http/Controllers/Admin/TreatmentResultController.php:144
 * @route '/admin/resultados/{result}'
 */
    const destroyForm = (args: { result: number | { id: number } } | [result: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\TreatmentResultController::destroy
 * @see app/Http/Controllers/Admin/TreatmentResultController.php:144
 * @route '/admin/resultados/{result}'
 */
        destroyForm.delete = (args: { result: number | { id: number } } | [result: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const TreatmentResultController = { index, store, update, toggleVisibility, destroy }

export default TreatmentResultController