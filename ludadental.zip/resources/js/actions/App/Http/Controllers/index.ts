import AppointmentController from './AppointmentController'
import Admin from './Admin'
import Settings from './Settings'
const Controllers = {
    AppointmentController: Object.assign(AppointmentController, AppointmentController),
Admin: Object.assign(Admin, Admin),
Settings: Object.assign(Settings, Settings),
}

export default Controllers