import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\AppointmentController::index
 * @see app/Http/Controllers/Admin/AppointmentController.php:22
 * @route '/admin/citas'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/citas',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\AppointmentController::index
 * @see app/Http/Controllers/Admin/AppointmentController.php:22
 * @route '/admin/citas'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AppointmentController::index
 * @see app/Http/Controllers/Admin/AppointmentController.php:22
 * @route '/admin/citas'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\AppointmentController::index
 * @see app/Http/Controllers/Admin/AppointmentController.php:22
 * @route '/admin/citas'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\AppointmentController::index
 * @see app/Http/Controllers/Admin/AppointmentController.php:22
 * @route '/admin/citas'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\AppointmentController::index
 * @see app/Http/Controllers/Admin/AppointmentController.php:22
 * @route '/admin/citas'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\AppointmentController::index
 * @see app/Http/Controllers/Admin/AppointmentController.php:22
 * @route '/admin/citas'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Admin\AppointmentController::estado
 * @see app/Http/Controllers/Admin/AppointmentController.php:74
 * @route '/admin/citas/{appointment}/estado'
 */
export const estado = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: estado.url(args, options),
    method: 'patch',
})

estado.definition = {
    methods: ["patch"],
    url: '/admin/citas/{appointment}/estado',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Admin\AppointmentController::estado
 * @see app/Http/Controllers/Admin/AppointmentController.php:74
 * @route '/admin/citas/{appointment}/estado'
 */
estado.url = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { appointment: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { appointment: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    appointment: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        appointment: typeof args.appointment === 'object'
                ? args.appointment.id
                : args.appointment,
                }

    return estado.definition.url
            .replace('{appointment}', parsedArgs.appointment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AppointmentController::estado
 * @see app/Http/Controllers/Admin/AppointmentController.php:74
 * @route '/admin/citas/{appointment}/estado'
 */
estado.patch = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: estado.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Admin\AppointmentController::estado
 * @see app/Http/Controllers/Admin/AppointmentController.php:74
 * @route '/admin/citas/{appointment}/estado'
 */
    const estadoForm = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: estado.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AppointmentController::estado
 * @see app/Http/Controllers/Admin/AppointmentController.php:74
 * @route '/admin/citas/{appointment}/estado'
 */
        estadoForm.patch = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: estado.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    estado.form = estadoForm
/**
* @see \App\Http\Controllers\Admin\AppointmentController::reagendar
 * @see app/Http/Controllers/Admin/AppointmentController.php:91
 * @route '/admin/citas/{appointment}/reagendar'
 */
export const reagendar = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: reagendar.url(args, options),
    method: 'patch',
})

reagendar.definition = {
    methods: ["patch"],
    url: '/admin/citas/{appointment}/reagendar',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Admin\AppointmentController::reagendar
 * @see app/Http/Controllers/Admin/AppointmentController.php:91
 * @route '/admin/citas/{appointment}/reagendar'
 */
reagendar.url = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { appointment: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { appointment: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    appointment: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        appointment: typeof args.appointment === 'object'
                ? args.appointment.id
                : args.appointment,
                }

    return reagendar.definition.url
            .replace('{appointment}', parsedArgs.appointment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AppointmentController::reagendar
 * @see app/Http/Controllers/Admin/AppointmentController.php:91
 * @route '/admin/citas/{appointment}/reagendar'
 */
reagendar.patch = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: reagendar.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Admin\AppointmentController::reagendar
 * @see app/Http/Controllers/Admin/AppointmentController.php:91
 * @route '/admin/citas/{appointment}/reagendar'
 */
    const reagendarForm = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: reagendar.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AppointmentController::reagendar
 * @see app/Http/Controllers/Admin/AppointmentController.php:91
 * @route '/admin/citas/{appointment}/reagendar'
 */
        reagendarForm.patch = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: reagendar.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    reagendar.form = reagendarForm
const citas = {
    index: Object.assign(index, index),
estado: Object.assign(estado, estado),
reagendar: Object.assign(reagendar, reagendar),
}

export default citas