import citas from './citas'
import resultados from './resultados'
const admin = {
    citas: Object.assign(citas, citas),
resultados: Object.assign(resultados, resultados),
}

export default admin